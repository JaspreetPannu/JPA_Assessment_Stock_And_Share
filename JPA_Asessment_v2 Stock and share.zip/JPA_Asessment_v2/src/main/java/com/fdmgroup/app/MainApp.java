package com.fdmgroup.app;


import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.fdmgroup.model.Company;
import com.fdmgroup.model.DirectHolder;

import com.fdmgroup.model.Stock;


public class MainApp {
	public static void main(String[] args) {
		

		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA_ASSESSMENT_2");
	        EntityManager em = emf.createEntityManager();
	      
	        em.getTransaction().begin();
	        
	        Stock s1 = new Stock();
	      
	        s1.setCurrentPrice(10.1);
	        s1.setStockSymbol("GOOG");
	        Stock s2 = new Stock();
	       
	        s2.setCurrentPrice(20.2);
	        s2.setStockSymbol("APPL");
	        
	        em.persist(s1);
	        em.persist(s2);
	        em.getTransaction().commit();
	        
	        em.getTransaction().begin();
	        DirectHolder d1 = new DirectHolder("Warren", "Buffet");
	        DirectHolder d2 = new DirectHolder("Bill", "Gates");
	        Company c1 = new Company("Google", 1997);
	        
	        em.persist(d1);
	        em.persist(d2);
	        em.persist(c1);

	        em.getTransaction().commit();
	        
	       
	        s1.getShareHolder().add(c1);
	        s1.getShareHolder().add(d1);
	        s2.getShareHolder().add(d1);
	        
	        c1.getStock().add(s1);
	        d1.getStock().add(s1);
	        d1.getStock().add(s2);
	        
	
	        em.getTransaction().begin();
		        em.persist(c1);	
		        em.persist(d1);
        	em.getTransaction().commit();
	        
	        em.getTransaction().begin();
	        	em.persist(s1);
	        	em.persist(s2);
	        em.getTransaction().commit();

	        List<Stock> stock = em.createNamedQuery("Stock.findPriceLessThan", Stock.class).setParameter("sprice", 15.00).getResultList();
	        for(Stock s : stock) {
	            System.out.println(s.getCurrentPrice());
	        }

	}

}
