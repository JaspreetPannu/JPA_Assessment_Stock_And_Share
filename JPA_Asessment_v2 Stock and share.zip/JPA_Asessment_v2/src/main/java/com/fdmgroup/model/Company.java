package com.fdmgroup.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "COMPANY")

public class Company extends ShareHolder {

	@Column(nullable = false)
	private String companyName;

	@Column(nullable = false)
	private int yearFounded;

	public Company() {
		super();
	}

	public Company(String companyName, int yearFounded) {
		super();
		this.companyName = companyName;
		this.yearFounded = yearFounded;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getYearFounded() {
		return yearFounded;
	}

	public void setYearFounded(int yearFounded) {
		this.yearFounded = yearFounded;
	}

	@Override
	public String toString() {
		return "Company [companyName=" + companyName + ", yearFounded=" + yearFounded + "]";
	}

}
