package com.fdmgroup.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SHAREHOLDER")
@Inheritance(strategy = InheritanceType.JOINED)

public class ShareHolder {
	
	@Id
	@Column(name = "SHAREHOLDER_ID")
	@SequenceGenerator(name = "SH_SEQ_GEN", sequenceName = "SH_PK_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SH_SEQ_GEN")
	private int shareHolderId;
	
	@Column(name = "YEAR_REGISTERED", nullable = false)
	private int yearRegistered;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JoinTable(name = "HOLDER_STOCK",
	joinColumns = @JoinColumn(name = "FK_SHARE_HOLDER_ID"),
	inverseJoinColumns = @JoinColumn(name = "FK_STOCK_ID"))
	private List<Stock> stock = new ArrayList<Stock>();

	public ShareHolder() {
		super();
	}
	
	public ShareHolder(int yearRegistered, List<Stock> stock) {
		super();
		this.yearRegistered = yearRegistered;
		this.stock = stock;
	}


	public int getShareHolderId() {
		return shareHolderId;
	}


	public int getYearRegistered() {
		return yearRegistered;
	}



	public void setYearRegistered(int yearRegistered) {
		this.yearRegistered = yearRegistered;
	}



	public List<Stock> getStock() {
		return stock;
	}



	public void setStock(List<Stock> stock) {
		this.stock = stock;
	}



	@Override
	public String toString() {
		return "ShareHolder [shareHolderId=" + shareHolderId + ", yearRegistered=" + yearRegistered + ", stock=" + stock
				+ "]";
	}
	
	
	
	
	
	
}
