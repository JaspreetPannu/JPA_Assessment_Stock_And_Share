package com.fdmgroup.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "STOCK", uniqueConstraints = {
		@UniqueConstraint(columnNames = "STOCK_SYMBOL") })
@NamedQueries({
	@NamedQuery(name = "Stock.findPriceLessThan", query = "SELECT s FROM Stock s WHERE s.currentPrice = :sprice")
})

public class Stock {

	@Id
	@Column(name = "STOCK_ID")
	@SequenceGenerator(name = "STOCK_SEQ_GEN", sequenceName = "STOCK_PK_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "STOCK_SEQ_GEN")
	private int stockId;
	
	@Column(name = "CURRENT_PRICE", nullable = false)
	private double currentPrice;
	
	@Column(name = "STOCK_SYMBOL",nullable = false)
	private String stockSymbol;
	
	@ManyToMany(mappedBy = "stock")
	private List<ShareHolder> shareHolder = new ArrayList<ShareHolder>();
	
	
	public Stock() {
		super();
	}

	public Stock(double currentPrice, String stockSymbol, List<ShareHolder> shareHolder) {
		super();
		this.currentPrice = currentPrice;
		this.stockSymbol = stockSymbol;
		this.shareHolder = shareHolder;
	}

	public int getStockId() {
		return stockId;
	}

	public double getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public String getStockSymbol() {
		return stockSymbol;
	}

	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}

	public List<ShareHolder> getShareHolder() {
		return shareHolder;
	}

	public void setShareHolder(List<ShareHolder> shareHolder) {
		this.shareHolder = shareHolder;
	}

	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", currentPrice=" + currentPrice + ", stockSymbol=" + stockSymbol
				+ ", shareHolder=" + shareHolder + "]";
	}

}